package br.edu.impacta.arq4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class SaudacaoServer {

	public static void main (String[] args) throws IOException{
		
		ServerSocket ss =  new ServerSocket(58888);
		
		while(true){
			
			System.out.println("Servidor esperando conex�o");
			Socket soc = ss.accept();
			System.out.println("Conectado!");
			InputStream is = soc.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			OutputStream os = soc.getOutputStream();
			PrintWriter	pw = new PrintWriter(os);
			String nome = br.readLine();
			Date data = new Date(0);
			SimpleDateFormat fmtData = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat fmtHora = new SimpleDateFormat("hh:mm:ss");
			String msg = "Ol�" + nome + "! ";
			msg += "Iaeeeeee a data �  " + fmtData.format(data);
			msg += "e o hora � " + fmtHora.format(data);
			pw.println(msg);
			pw.flush();
			pw.close();
			br.close();
			soc.close();
			 
			
			
		}
		
	}



}
